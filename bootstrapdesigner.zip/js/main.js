$(document).ready(function () {

    var secilen = null
    var itemPlaceX = 0
    var itemPlaceY = 0
    var hedef = null
    var itemID = 1
    $(".drawItem").on("mousedown",function (e) {
        itemPlaceX = e.pageX
        itemPlaceY = e.pageY
        secilen = $(this)
    })
    $("body").on("mousemove",function (e) {
        if (secilen!=null){
            secilen.attr("style","position:fixed;z-index:99999;top:"+(e.pageY - 10)+"px;left:"+(e.pageX - 15)+"px;")
        }
    })
    $(".drawItem").on("mouseup",function (e) {
        if (hedef!=null){
            itemID = itemID+1
            var data = $("#"+secilen.attr("type")).html()
            $("#"+hedef).append(data.replace("items","item"+itemID))
            secilen.attr("style","")
            secilen = null
            hedef = null
        }
    })
    $(".item").on("mouseover",function (e) {
        hedef = e.target.getAttribute("id")
    })

    $(".item").on("dblclick",function (e) {
        e.target.remove()
    })


    $("#download").on("click",function () {
        var realCode = $("#editor").html()
        //$("#editor *").removeClass("item")
        var newCode = "<html>\n" +
            "    <head>\n" +
            "        <meta charset=\"UTF-8\">\n" +
            "        <title>Theme By Website Theme Generator</title>\n" +
            "        <script\n" +
            "                src=\"https://code.jquery.com/jquery-3.4.1.slim.js\"\n" +
            "                integrity=\"sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=\"\n" +
            "                crossorigin=\"anonymous\"></script>\n" +
            "        <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\">\n" +
            "        <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\"></script>\n" +
            "        <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js\"></script>\n" +
            "    </head>\n" +
            "<body>"
        newCode+=realCode
        newCode+="\n</body>\n</html>"
        $("#sourcecode").val(newCode)
        $("#goster").trigger("click")
    })
})